package painting;

import java.awt.*;

public interface Paint {

    Color Paint();
}

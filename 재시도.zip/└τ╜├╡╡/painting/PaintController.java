package painting;

public class PaintController {
}

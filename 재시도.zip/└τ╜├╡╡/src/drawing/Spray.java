package drawing;

public class Spray implements Draw{
}

package drawing;

public enum Drawing {
    PEN,
    BRUSH,
    SPRAY,
}

package lineDesign;

public class LineBold {
}

package action;

import drawing.Pen;
import painting.ColorType;
import text.TextBox;
import user.UserSelection;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class ButtonAction implements ActionListener {

    private UserSelection userSelection;

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton selectButton = (JButton) e.getSource();

        String Name=selectButton.getName();
        if (Name.equals("25_pen")) {
            // Pen 버튼을 눌렀을 때 
            Pen pen= new Pen();
            //pen.draw((Button) selectButton);
        } else if (Name.equals("28_textBox")) {
            TextBox textBox = new TextBox();
            textBox.setCreating();

        } else if (Name.equals("05_red")) {
            UserSelection userSelection = new UserSelection(ColorType.RED);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());
        

        } else if (Name.equals("06_yellow")) {
            UserSelection userSelection = new UserSelection(ColorType.YELLOW);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("07_green")) {
            UserSelection userSelection = new UserSelection(ColorType.GREEN);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("09_blue")) {
            UserSelection userSelection = new UserSelection(ColorType.BLUE);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("10_brown")) {
            UserSelection userSelection = new UserSelection(ColorType.BROWN);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("11_grey")) {
            UserSelection userSelection = new UserSelection(ColorType.GREY);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("13_white")) {
            UserSelection userSelection = new UserSelection(ColorType.WHITE);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("14_black")) {
            UserSelection userSelection = new UserSelection(ColorType.BLACK);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        }else if (Name.equals("15_customColor")) {
            UserSelection userSelection = new UserSelection(ColorType.CUSTOM);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());
        
        }
    }    
    
}


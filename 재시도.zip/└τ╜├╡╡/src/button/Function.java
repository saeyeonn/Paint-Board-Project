package button;

public enum Function {
    COLOR_VERSION,
    DOING,
    DRAWING,
    SHAPE,
    ERASER,
    GROUPING,
    LINE_SETTING,
    PAINTING,
    TEXT,
    UTILITY,
    ZOOM,
}

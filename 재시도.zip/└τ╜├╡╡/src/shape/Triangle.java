package shape;

public class Triangle implements Shaping {
}

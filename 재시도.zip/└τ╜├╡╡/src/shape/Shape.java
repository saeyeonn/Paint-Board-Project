package shape;

public enum Shape {
    LINE,
    RECTANGULAR,
    TRIANGLE,
    CIRCLE,
}

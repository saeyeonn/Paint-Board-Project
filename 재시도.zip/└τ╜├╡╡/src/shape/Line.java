package shape;

public class Line implements Shaping {
}

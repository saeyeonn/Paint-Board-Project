package zoom;

public class ZoomIn {
}

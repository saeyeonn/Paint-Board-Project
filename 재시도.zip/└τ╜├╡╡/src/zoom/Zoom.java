package zoom;

public enum Zoom {
    IN,
    OUT,
}

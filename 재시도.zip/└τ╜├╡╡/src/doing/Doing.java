package doing;

public enum Doing {
    UNDO,
    REDO,
}

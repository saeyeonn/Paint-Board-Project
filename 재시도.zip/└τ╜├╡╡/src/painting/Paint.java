package painting;

public interface Paint {
}

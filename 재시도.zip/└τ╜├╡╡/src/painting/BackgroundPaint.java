package painting;

public class BackgroundPaint implements Paint {
}

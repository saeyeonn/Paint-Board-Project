package painting;

public class ColorService {
}

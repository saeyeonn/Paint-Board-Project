package painting;

public class ShapePaint implements Paint {
}

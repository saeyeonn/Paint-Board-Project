package text;

public enum Text {
    BOX,
    FONT,
    SIZE,
    BOLD,
    UNDERLINE,
}

package utility;

public class Paste {
}

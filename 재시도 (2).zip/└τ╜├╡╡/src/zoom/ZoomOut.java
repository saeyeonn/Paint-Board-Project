package zoom;

public class ZoomOut {
}

package shape;

public class Circle implements Shaping {
}

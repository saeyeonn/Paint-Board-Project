package shape;

public class Rectangular implements Shaping{
}

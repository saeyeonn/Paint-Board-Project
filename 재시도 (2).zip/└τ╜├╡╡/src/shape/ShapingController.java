package shape;

public class ShapingController {
}

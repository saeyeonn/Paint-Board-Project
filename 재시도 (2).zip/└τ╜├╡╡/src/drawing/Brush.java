package drawing;

import javax.swing.*;
import java.awt.*;

public class Brush implements Draw {


}


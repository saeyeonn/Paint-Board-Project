package action;

import drawing.Pen;
import painting.BackgroundPaint;
import painting.ColorType;
import text.TextBox;
import user.UserSelection;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class ButtonAction implements ActionListener {

    private UserSelection userSelection;

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton selectButton = (JButton) e.getSource();

        String Name = selectButton.getName();
        if (Name.equals("25_pen")) {
            // Pen 버튼을 눌렀을 때 
            Pen pen = new Pen();
            //pen.draw((Button) selectButton);
        } else if (Name.equals("28_textBox")) {
            TextBox textBox = new TextBox();
            textBox.setCreating();

        } else if (Name.equals("05_red")) {
            userSelection = new UserSelection(ColorType.RED);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("06_yellow")) {
            userSelection = new UserSelection(ColorType.YELLOW);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("07_green")) {
            userSelection = new UserSelection(ColorType.GREEN);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("09_blue")) {
            userSelection = new UserSelection(ColorType.BLUE);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("10_brown")) {
            userSelection = new UserSelection(ColorType.BROWN);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("11_grey")) {
            userSelection = new UserSelection(ColorType.GREY);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("13_white")) {
            userSelection = new UserSelection(ColorType.WHITE);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("14_black")) {
            userSelection = new UserSelection(ColorType.BLACK);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("15_customColor")) {
            userSelection = new UserSelection(ColorType.CUSTOM);
            System.out.println("현재 선택된 색: " + userSelection.getColorType());

        } else if (Name.equals("08_backgroundColor")) {
            if (userSelection == null) {
                System.out.println("배경색을 변경할 색상을 선택해주세요.");
            } else {
                BackgroundPaint backgroundPaint = new BackgroundPaint(userSelection);
                System.out.println("선택된 배경 색: " + backgroundPaint.getBackgroundColor(userSelection));
            }
        }
        
        }
    private void updateUserSelection(ColorType colorType) {
        if (userSelection == null) {
            userSelection = new UserSelection(colorType);
        } else {
            userSelection.setColorType(colorType);
        }
        System.out.println("현재 선택된 색: " + userSelection.getColorType());
    }

}
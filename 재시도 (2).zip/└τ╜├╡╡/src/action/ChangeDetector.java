package action;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ChangeDetector implements ChangeListener {
    @Override
    public void stateChanged(ChangeEvent e) {

    }
}

package eraser;

public enum Eraser {
    PIXEL,
    LINE,
}

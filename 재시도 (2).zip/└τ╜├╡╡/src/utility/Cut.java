package utility;

public class Cut {
}

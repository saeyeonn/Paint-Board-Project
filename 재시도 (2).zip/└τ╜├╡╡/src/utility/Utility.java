package utility;

public enum Utility {
    SAVE,
    LOAD,
    CUT,
    PASTE,
    RESET
}

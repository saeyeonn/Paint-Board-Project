import window.WindowController;

public class PaintBoardApplication {
    public static void main(String[] args) {
        WindowController.initialize();
    }
}
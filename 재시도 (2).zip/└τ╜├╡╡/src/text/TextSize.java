package text;

public class TextSize {
}

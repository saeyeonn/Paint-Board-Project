package text;

public enum FontType {
    Arial,
    etc,
}

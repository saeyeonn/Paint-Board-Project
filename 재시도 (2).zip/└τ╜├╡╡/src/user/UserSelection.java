package user;

import painting.ColorType;

public class UserSelection {

    private ColorType colorType;

    public UserSelection(ColorType colorType) {
        this.colorType = colorType;
    }

    public void setColorType(ColorType colorType) {
        this.colorType = colorType;
    }

    public ColorType getColorType() {
        return colorType;
    }
}



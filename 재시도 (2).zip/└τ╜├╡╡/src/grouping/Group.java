package grouping;

public class Group {
}

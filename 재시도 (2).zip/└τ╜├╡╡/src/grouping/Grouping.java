package grouping;

public enum Grouping {
    GROUP,
    UNGROUP,
}

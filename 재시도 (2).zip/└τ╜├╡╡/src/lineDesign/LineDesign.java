package lineDesign;

public enum LineDesign {
    TYPE,
    BOLD,
}

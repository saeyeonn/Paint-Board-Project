package lineDesign;

public class LineType {
}

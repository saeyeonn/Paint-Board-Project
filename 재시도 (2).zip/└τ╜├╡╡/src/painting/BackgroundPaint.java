package painting;

import user.UserSelection;

public class BackgroundPaint implements Paint {

    private UserSelection backgroundColor;
    backgroundColor = Color.WHITE;

    public BackgroundPaint(UserSelection backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public UserSelection getBackgroundColor(UserSelection backgroundColor) {
        return backgroundColor;
    }

    public void setBackgroundColor(UserSelection backgroundColor) {
        this.backgroundColor = backgroundColor;
    }
}

package painting;

public enum Painting {
    BACKGROUND,
    INTERIOR_SHAPE,
}

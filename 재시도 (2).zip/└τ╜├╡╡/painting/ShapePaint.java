package painting;

import java.awt.*;

public class ShapePaint implements Paint {
    @Override
    public Color Paint() {
        return null;
    }
}
